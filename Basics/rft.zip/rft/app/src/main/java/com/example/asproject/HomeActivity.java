package com.example.asproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.asproject.inHome.AboutActivity;
import com.example.asproject.inHome.DatabaseAcivity;
import com.example.asproject.quiz.QuizMainActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTitle("Home");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }

    public void handleBD(View view) {
        startActivity(new Intent(getApplicationContext(), DatabaseAcivity.class));
    }

    public void handleInfo(View view) {
        startActivity(new Intent(getApplicationContext(), AboutActivity.class));
    }

    public void handleQuiz(View view) {
        startActivity(new Intent(getApplicationContext(), QuizMainActivity.class));
    }

    public void handleCalculator(View view) {
        startActivity(new Intent(getApplicationContext(), CaluclatorActivity.class));
    }
}