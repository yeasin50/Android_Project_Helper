package com.example.asproject.inHome;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.asproject.R;

public class AboutActivity extends AppCompatActivity {

    String aboutText =" Md.Rifat Islam\n Id:181-15-xxxx\n Section: PC-A\n Department: CSE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        setTitle("About");

        TextView textView = findViewById(R.id.textViewAboutText);
        textView.setText(aboutText);
        textView.setTextSize(24);
        textView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
    }
}