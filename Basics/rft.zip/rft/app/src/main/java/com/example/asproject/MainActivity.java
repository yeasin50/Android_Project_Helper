package com.example.asproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "MainActivity";

    EditText editTextPin, editTextUserName;
    Button btnverify;
    final String verifiedPin = "123";
    final String verifiedName ="admin";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextPin = findViewById(R.id.editTextPin);
        editTextUserName = findViewById(R.id.editTextUserName);
        btnverify = findViewById(R.id.btnVerify);

        btnverify.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnVerify) {
            String pin = editTextPin.getText().toString().trim();
            String userName = editTextUserName.getText().toString().trim();

            Log.i(TAG, "onClick: " + pin + "  name " + userName);
            if (pin.isEmpty()) {
                editTextPin.setError("Enter pin");
                editTextPin.requestFocus();
                return;
            }
            if (userName.isEmpty()) {
                editTextUserName.setError("Please enter userName");
                editTextUserName.requestFocus();
                return;
            }

            if (!userName.equals(verifiedName)) {
                editTextUserName.setError("invalid username");
                editTextUserName.requestFocus();
                return;
            }
            if (!verifiedPin.equals(verifiedPin)) {
                editTextPin.setError("Enter valid pin");
                editTextPin.requestFocus();
                return;
            }

            startActivity(new Intent(getApplicationContext(), HomeActivity.class));

        }


}}