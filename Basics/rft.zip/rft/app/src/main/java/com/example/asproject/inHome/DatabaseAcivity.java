package com.example.asproject.inHome;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.asproject.R;
import com.example.asproject.dbHelper.MyDBHelper;

import java.sql.SQLDataException;

public class DatabaseAcivity extends AppCompatActivity {


    EditText editTextName, editTextScore;
    Button btnSave,btnViewDB;
    MyDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database_acivity);
        setTitle("Databases");

        //DB localization
        dbHelper = new MyDBHelper(this);
        SQLiteDatabase sqlDataException = dbHelper.getWritableDatabase();


        editTextName = findViewById(R.id.editTextName);
        editTextScore = findViewById(R.id.editTextValue);

        btnSave = findViewById(R.id.btnSaveDB);
        btnViewDB = findViewById(R.id.btnViewDataBase);

        btnViewDB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preViewDB();
            }
        });
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String item =editTextName.getText().toString();
                String value = editTextScore.getText().toString();
                if(item.isEmpty()){
                    editTextName.setError("enter name");
                    editTextName.requestFocus();
                    return;
                }
                if(value.isEmpty()){
                    editTextScore.setError("enter value");
                    editTextScore.requestFocus();
                    return;
                }
                saveData(item, value);
            }
        });


    }

    void saveData(String item, String value){
        long rowID = dbHelper.insertData(item,value);
        if(rowID == -1){
            Toast.makeText(getApplicationContext(),"Failed to save" , Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(getApplicationContext(),item+" saved" , Toast.LENGTH_LONG).show();
        }
    }

    void preViewDB(){
        Cursor cursor = dbHelper.viewData();
        if(cursor.getCount()==0){
            show_Dialog("Empty DB", "Save Data and try again");
        return;
        }
        StringBuffer stringBuffer = new StringBuffer();
        while (cursor.moveToNext()){
            stringBuffer.append("Item : "+ cursor.getString(0)+"\n");
            stringBuffer.append("Value : "+ cursor.getString(1)+"\n\n");
        }
        show_Dialog ("Stored Data",stringBuffer.toString());


    }

    private void show_Dialog(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setCancelable(true);
        builder.show();
    }
}