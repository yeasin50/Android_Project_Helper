package com.example.asproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class SpinnerAcitivity extends AppCompatActivity {

    Spinner spinner;
    String[] CountryNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spinner_acitivity);

        setContentView(R.layout.activity_main);
        spinner = findViewById(R.id.spinnerId);
        CountryNames = getResources().getStringArray(R.array.Country_Name);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.sample_layout, R.id.TVId1, CountryNames);
        spinner.setAdapter(adapter);

    }
}