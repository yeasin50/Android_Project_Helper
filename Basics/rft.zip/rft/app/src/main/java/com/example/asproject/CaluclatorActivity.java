package com.example.asproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CaluclatorActivity extends AppCompatActivity {

    private static final String TAG = "CaluclatorActivity";

    TextView textViewResult;
    int result =0;
    Button btn1, btn2, btn3,btn4,btn5, btnClr, btnAdd, btnMin, btnEqual;
    String temp="";
    String operator="+";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caluclator);

        setTitle("CaluCulu");
        findViewById(R.id.backBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), HomeActivity.class));
            }
        });
        textViewResult = findViewById(R.id.resultTextView);
        textViewResult.setText(result+"");

        btn1 = findViewById(R.id.buttonOne);
        btn2 = findViewById(R.id.buttonTwo);
        btn3 = findViewById(R.id.button3);
        btn4 = findViewById(R.id.button4);
        btn5 = findViewById(R.id.button5);

        btnClr = findViewById(R.id.buttonClear);
        btnMin = findViewById(R.id.buttonMin);
        btnAdd = findViewById(R.id.buttonADd);
        btnEqual = findViewById(R.id.buttonEqual);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setTextViewResult(temp+="1");
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setTextViewResult(temp+="2");
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setTextViewResult(temp+="3");
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setTextViewResult(temp+="4");
            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setTextViewResult(temp+="5");
            }
        });


        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                result = result +Integer.parseInt(operator.isEmpty()?"":operator+ (temp.isEmpty()?"0":temp));
//                setTextViewResult(result+"");

                if(!temp.isEmpty() && !operator.isEmpty()){
                    if(operator.equals("+")){
                        result = result + Integer.parseInt(temp);
                    }else {
                        result -=Integer.parseInt(temp);
                    }

                }
                setTextViewResult(result+"");
                temp="";
                operator ="+";
            }
        });
        btnMin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                result = result +Integer.parseInt(operator.isEmpty()?"":operator+ (temp.isEmpty()?"0":temp));
                if(!temp.isEmpty() && !operator.isEmpty()){
                    if(operator.equals("+")){
                        result = result + Integer.parseInt(temp);
                    }else {
                        result = result - Integer.parseInt(temp);
                    }

                }
                if(operator.isEmpty() && !temp.isEmpty()){
                    result = Integer.parseInt(temp);
                }
                setTextViewResult(result+"");
                operator ="-";
                temp="";
            }
        });
        btnEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!temp.isEmpty() && !operator.isEmpty()){
                    if(operator.equals("+")){
                        result = result + Integer.parseInt(temp);
                    }else {
                        result = result - Integer.parseInt(temp);
                    }

                }
                setTextViewResult(result+"");
                operator="+";
                temp="";
                result=0;
            }
        });
        btnClr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                result=0;
                temp="";
                setTextViewResult(result+"");
                operator="+";
            }
        });
    }

    void setTextViewResult(String r){
        textViewResult.setText(r);
        Log.i(TAG, "setTextViewResult: "+ r);
    }
}